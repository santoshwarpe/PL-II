package demo;

import java.util.*;
import javax.mail.*;
 
public class msgshow {
 
    public static void main(String[] args) throws Exception {
        Properties props = System.getProperties();
        props.setProperty("mail.pop3.port", "995");
        Session session = Session.getInstance(props, null);
        Store store = session.getStore("imaps");
 
        store.connect("pop.gmail.com", "username", "password");
        Folder inbox = store.getFolder("INBOX");
        inbox.open(Folder.READ_ONLY);
       
        for (int i = 1;i <= 1; i++){
 
             	inbox.getMessage(i).getHeader("Message-Id"); 
            Enumeration headers = inbox.getMessage(i).getAllHeaders();
 
            while (headers.hasMoreElements()) {
                Header h = (Header) headers.nextElement();
                System.out.println(h.getName() + ":" + h.getValue());
                  
                String mID = h.getName(); 
             
            }
        }
        inbox.close(true);
    }
}